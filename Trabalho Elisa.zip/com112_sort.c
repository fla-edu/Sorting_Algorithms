#include <stdio.h>
#include <stdlib.h>
#include "com112_sort.h"
#include "com112_file.h"

typedef struct numerosDesordenados {
    int v[], n;
}Desordenados;

Desordenados *criaNumero(int n) {
    Desordenados *c;
    c = (Desordenados*) malloc(sizeof(n*Desordenados));
    if(!c) {
        printf("Erro ao alocar os números\n");
        exit(1);
    }
}

void mostraValores(int v[], int n) {
    int i;
    //MOSTRANDO OS NÚMEROS ORDENADOS
    printf("\nNúmeros ordenados:    ");
    for (i = 0; i < n; i++) {
        printf("%d ", v[i]);
    }
    printf("\n\n");
}

//Versão Melhorada 2 do Bubble Sort
void bubbleSort2(int v[], int n) {
    int i, j, houve_troca = 1, aux;
    //MOSTRANDO OS NÚMEROS DESORDENADOS
    i = 1;
    while (i <= n && houve_troca == 1) {
        houve_troca = 0;
        for (j = 0; j < n - 1; j++) {
            if (v[j] > v[j + 1]) {
                aux = v[j];
                v[j] = v[j + 1];
                v[j + 1] = aux;
                houve_troca = 1;
            }
        }
        i++;
    }
}

//Selection Sort

void selectionSort(int v[], int n) {
    int i, j, eleito, menor, pos;

    for (i = 0; i < n - 1; i++) {
        eleito = v[i];
        menor = v[i + 1];
        pos = i + 1;
        for (j = i + 1; j < n; j++) {
            if (v[j] < menor) {
                menor = v[j];
                pos = j;
            }
        }
        if (menor < eleito) {
            v[i] = v[pos];
            v[pos] = eleito;
        }
    }
}


//Inserction Sort

void insertionSort(int v[], int n) {
    int i, j, eleito;
    for (i = 1; i <= n - 1; i++) {
        eleito = v[i];
        j = i - 1;
        while (j >= 0 && v[j] > eleito) {
            v[j + 1] = v[j];
            j--;
        }
        v[j + 1] = eleito;
    }
}

//Merge Sort - Recursiva

void mergeSort(int v[], int inicio, int fim) {
    int meio;
    if (inicio < fim) {
        meio = (inicio + fim) / 2;
        mergeSort(v, inicio, meio);
        mergeSort(v, meio + 1, fim);
        merge(v, inicio, fim, meio);
    }
}

//Merge Sort - Ordenação

void merge(int v[], int inicio, int fim, int meio) {
    int posLivre, inicio_v1, inicio_v2, i;
    int aux[5];
    inicio_v1 = inicio;
    inicio_v2 = meio + 1;
    posLivre = inicio;

    while (inicio_v1 <= meio && inicio_v2 <= fim) {
        if (v[inicio_v1] <= v[inicio_v2]) {
            aux[posLivre] = v[inicio_v1];
            inicio_v1++;
        } else {
            aux[posLivre] = v[inicio_v2];
            inicio_v2++;
        }
        posLivre++;
    }
    //Caso haja números no primeiro vetor que não foram intercalados
    for (i = inicio_v1; i <= meio; i++) {
        aux[posLivre] = v[i];
        posLivre++;
    }
    //Caso haja número no segundo vetor que não foram intercalados
    for (i = inicio_v2; i <= fim; i++) {
        aux[posLivre] = v[i];
        posLivre++;
    }
    //Retorna os valores de aux para o vetor
    for (i = inicio; i <= fim; i++) {
        v[i] = aux[i];
    }
}
