#include <stdio.h>
#include <stdlib.h>
#include "com112_sort.h"
#include "com112_file.h"

FILE *arquivo;
void gerarNumeros(Desordenados *d) {

}

void lerNumeros(Desordenados *d) {
    arquivo = fopen("com112_entrada.txt", "r");
    fscanf(arquivo, "%d ", &d->n);
    
    while() {
	}
}