#ifndef COM112_SORT_H
#define COM112_SORT_H

typedef struct numerosDesordenados Desordenados;     
Desordenados *criaVetor(int n);
void bubbleSort2(int v[], int n);                       //Bubble Sort Melhorado 2
void selectionSort(int v[], int n);                     //Selection Sort    
void insertionSort(int v[], int n);                     //Insertion Sort
void mergeSort(int v[], int inicio, int fim);           //Merge Sort - Recursiva
void merge(int v[], int inicio, int fim, int meio);     //Merge Sort - Intercala
void mostraValores(int v[], int n);                     //Função que mostra os valores

#endif /* COM112_SORT_H */

