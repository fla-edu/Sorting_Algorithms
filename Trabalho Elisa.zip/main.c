#include <stdio.h>
#include <stdlib.h>
#include "com112_sort.h"
#include "com112_file.h"

FILE *arquivo;

int menu(int v[], int n);
void relatorio(int v[],int n);

int main() {
    
    return 0;
}

//Menu de opções

int menu(int v[], int n) {
    int x, i, j;
    printf("--------------MÉTODOS DE ORDENAÇÃO--------------\n\n");
    printf("1 - Bubble Sort - Versão Melhorada 2\n");
    printf("2 - Selection Sort\n");
    printf("3 - Insertion Sort\n");
    printf("4 - Merge Sort\n");
    printf("5 - Quick Sort\n");
    printf("0 - Sair\n");
    printf("Digite um número: ");
    scanf("%d", &x);
    //Sair do menu
    if (x == 0)
        return 0;
    //Número inválido
    if (x < 0 || x > 6) {
        printf("\nNúmero Inválido!\n\n");
        return x;
    }
    //Números para ordenar
    printf("\nDigite 5 números para ordenar: \n");
    for (i = 0; i < n; i++) {
        scanf("%d", &v[i]);
    }
    //Mostrando números desordenados
    printf("\nNúmeros desordenados: ");
    for (i = 0; i < n; i++) {
        printf("%d ", v[i]);
    }
    if (x == 1)
        bubbleSort2(v, n);
    if (x == 2)
        selectionSort(v, n);
    if (x == 3)
        insertionSort(v, n);
    if (x == 4)
        mergeSort(v, 0, n - 1);
    //if (x == 5)
    //  quickSort();
    mostraValores(v, n);
    return x;
}

//Gera relatório de tempo de execução, número de movimentos e comparações
void relatorio(int v[],int n) {
    
}