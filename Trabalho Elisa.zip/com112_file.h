#ifndef COM112_FILE_H
#define COM112_FILE_H

//Gerar números aleatórios no arquivo
void gerarNumeros(Desordenados *d);

//Ler os números dos arquivos
void lerNumeros(Desordenados *d);


#endif /* COM112_FILE_H */

